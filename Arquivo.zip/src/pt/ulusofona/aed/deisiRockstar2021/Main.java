package pt.ulusofona.aed.deisiRockstar2021;

import java.util.*;
import java.io.*;
public class Main {
    public static HashSet<Song> listadeSons;
    public static  ArrayList<Artista> listadeArtistas;
    public static HashSet<Song> listadetalhes;
    public static  ArrayList<Song> listadeSons2;
    public static  ArrayList<Song> listaDetalhes2;
    public static ParseInfo infoSongs = new ParseInfo(0,0);
    public static ParseInfo infoSongs1 = new ParseInfo(0,0);
    public static ParseInfo infoSongs2 = new ParseInfo(0,0);

    public static void loadFiles() throws IOException {
        String ficheiro_songs = "songs.txt";
        try {
            listadeSons = new HashSet<Song>();
            listadeSons2 = new ArrayList<Song>();
            infoSongs2 = new ParseInfo(0,0);
            File ficheiro = new File(ficheiro_songs);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            HashSet<String> guardaIDs = new HashSet<String>();
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine();
                String dados[] = linha.split("@");
                if (dados.length == 3) {
                    int EncontrouDuplicadoId = 0;
                    dados[0] = dados[0].trim();
                    String ID = dados[0];
                    if (!guardaIDs.add(ID)) {
                        infoSongs2.numLinhasIgnored++;
                        EncontrouDuplicadoId = 1; // uma musica ja tem esse id
                    }
                    if (EncontrouDuplicadoId == 0){
                        dados[1] = dados[1].trim();
                        String nome = dados[1];
                        dados[2] = dados[2].trim();
                        int ano = Integer.parseInt(dados[2]);
                        // Criar objetos artistas
                        Song sons = new Song(ID, nome, ano);
                        listadeSons.add(sons);
                        listadeSons2.add(sons);
                        infoSongs2.numLinhasOk++;
                        guardaIDs.add(ID);
                    }
                } else {
                    infoSongs2.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_songs + " não foi encontrado. ";
            System.out.println(mensagem);
        }
        ///////// FIM de Leitura de Songs/////////////////////////
        String ficheiro_song_details = "song_details.txt";
        try {
            listadetalhes = new HashSet<Song>();
            listaDetalhes2 = new ArrayList<Song>();
            infoSongs1 = new ParseInfo(0,0);
            File ficheiro = new File(ficheiro_song_details);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            HashSet<String> guardaIDs2 = new HashSet<String>();
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine();// Ler a linha do ficheiro
                String dados[] = linha.split("@");
                if (dados.length == 7) {
                    int EncontrouDuplicadoId2 = 0;
                    dados[0] = dados[0].trim();
                    String ID = dados[0]; // ID tema musical
                    if (ID.equals("")) { // id inexistente
                        infoSongs1.numLinhasIgnored++;
                    } else {
                        if (!guardaIDs2.add(ID)) {
                            infoSongs1.numLinhasIgnored++;
                            EncontrouDuplicadoId2 = 1; // uma musica ja tem esse id
                        }
                        if (EncontrouDuplicadoId2 == 0) {
                            dados[1] = dados[1].trim();
                            int duracao = Integer.parseInt(dados[1]); // duracao
                            dados[2] = dados[2].trim();
                            int letra = Integer.parseInt(dados[2]);  // letra
                            dados[3] = dados[3].trim();
                            double popularidade = Double.parseDouble(dados[3]); // popularidade
                            dados[4] = dados[4].trim();
                            double dancabilidade = Double.parseDouble(dados[4]); // dancabilidade
                            dados[5] = dados[5].trim();
                            double vivacidade = Double.parseDouble(dados[5]);  // dancabilidade
                            dados[6] = dados[6].trim();
                            double volumeMedio = Double.parseDouble(dados[6]); // volume medio
                            // Criar objeto artistas
                            Song detalhes = new Song(ID, duracao, letra, popularidade, dancabilidade, vivacidade, volumeMedio);
                            listadetalhes.add(detalhes);
                            listaDetalhes2.add(detalhes);
                            guardaIDs2.add(ID);
                            infoSongs1.numLinhasOk++;
                        }
                    }
                } else {
                    infoSongs1.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_song_details + " não foi encontrado. ";
            System.out.println(mensagem);
        }
        //////// fim do ficheiro detalhes.txt///////////////////////
        String ficheiro_song_artits = "song_artists.txt";
        try {
            listadeArtistas= new ArrayList<Artista>();
            infoSongs = new ParseInfo(0,0);
            ArrayList<Song> OrdenadoPB = new ArrayList<>(); //copiar songs de forma ordenanda
            OrdenadoPB.addAll(listadeSons2);
            OrdenadoPB.sort(Comparator.comparing((Song som1) -> som1.iD)); //ordernado por IDs os detalhes
            File ficheiro = new File(ficheiro_song_artits);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine(); // Ler a linha do ficheiro
                String dados[] = linha.split("@");
                int temArtistaVazio = 0;
                if (dados.length == 2) {
                    String ID = dados[0].trim();
                    if (ID.equals("") || !verificarIDvalido(OrdenadoPB,ID)) { // se nao tiver id
                        infoSongs.numLinhasIgnored++;
                    } else {
                        if (dados[1].contains(",")) { // caso seja mais que um artista
                            String[] nomes = dados[1].split(","); //dividir por ,
                            for (String nome : nomes) {
                                nome = nome.replace("[", "").replace("]", "").replace("'", "").replace("\"", ""); //retirar peliculas e '
                                nome = nome.substring(0, 0) + nome.substring(1); // retirar o espaco inicial antes do @
                                if (nome.equals("")) {
                                    temArtistaVazio = 1;
                                }
                            }
                            if (temArtistaVazio == 1) {
                                infoSongs.numLinhasIgnored++; // encontrou artista vazio por isso ignora
                            } else {
                                for (String nome : nomes) {
                                    nome = nome.replace("[", "").replace("]", "").replace("'", "").replace("\"", ""); //retirar peliculas e '
                                    nome = nome.substring(0, 0) + nome.substring(1); // retirar o espaco inicial antes do @
                                    Artista artista = new Artista(ID, nome);
                                    listadeArtistas.add(artista);
                                }
                                infoSongs.numLinhasOk++; // leu a linha toda
                            }
                        } else { // tem apenas uma artista
                            String nome = dados[1].replace("[", "").replace("]", "").replace("'", "").replace("\"", ""); // retirar peliculas e []
                            nome = nome.substring(0, 0) + nome.substring(1); // retirar o espaco inicial antes do @
                            if (nome.equals("")) {
                                infoSongs.numLinhasIgnored++; // encontrou artista vazio por isso ignora
                                continue;
                            }
                            // Criar objeto artistas
                            Artista artista = new Artista(ID, nome);
                            listadeArtistas.add(artista);
                            infoSongs.numLinhasOk++;
                        }
                    }
                } else {
                    infoSongs.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_song_artits + " não foi encontrado. ";
            System.out.println(mensagem);
        }
    }
    public static ParseInfo getParseInfo(String fileName) {
        if (fileName.equals("song_artists.txt")) {
            return infoSongs;
        }
        if (fileName.equals("songs.txt")) {
            return infoSongs2;
        }
        if (fileName.equals("song_details.txt")) {
            return infoSongs1;
        }
        return null;
    }
    public static ArrayList<Song> getSongs() {
        return listadeSons2;
    }
    public static String getCreativeQuery() {
        return "GET_MOST_DURATION_YEAR";
    }
    public  static int getTypeOfSecondParameter() {
        return 1;
    }
    public static String getVideoUrl(){
        return "https://www.youtube.com/watch?v=NpIwiELjyi4&t=108s";
    }

    public static boolean verificarIDvalido(ArrayList<Song> copia ,String Id) {
        return FunctionsSongs.binarySearch(copia, Id) != -1;
    }
    public static String execute(String command) {
        String[] input = command.split(" ",2); // divide a string em espacos mas com limite dois
        switch (input[0]) {
            case "COUNT_SONGS_YEAR":
                int ano = Integer.parseInt(input[1]);
                return Integer.toString(FunctionsSongs.countSongsYear(listadeSons, ano));

            case "COUNT_DUPLICATE_SONGS_YEAR":
                int anoDuplicado = Integer.parseInt(input[1]);
                return Integer.toString(FunctionsSongs.countDuplicateSongsYear(listadeSons, anoDuplicado));

            case "GET_ARTISTS_FOR_TAG":
                String tagPedida = input[1].trim().toUpperCase();
                return FunctionsArtist.get_ArtistForTag(listadeArtistas,tagPedida);

            case "GET_MOST_DANCEABLE":
                String[] dados = input[1].split(" ");
                int anoInicio = Integer.parseInt(dados[0]);
                int anoFim = Integer.parseInt(dados[1]);
                int nrMusicas = Integer.parseInt(dados[2]);
                return FunctionsSongs.getMostDanceable(listadeSons,listadetalhes, anoInicio, anoFim, nrMusicas);

            case "GET_ARTISTS_ONE_SONG":
                String[] dadosAnosArtistas = input[1].split(" ");
                int anoInicioArtistas = Integer.parseInt(dadosAnosArtistas[0]);
                int anoFimArtistas = Integer.parseInt(dadosAnosArtistas[1]);
                return FunctionsArtist.getArtistsOneSong(anoInicioArtistas,anoFimArtistas);

            case "GET_TOP_ARTISTS_WITH_SONGS_BETWEEN":
                return "d";
            case "MOST_FREQUENT_WORDS_IN_ARTIST_NAME":
                return "e";
            case "GET_UNIQUE_TAGS":
               return "w" ;
            case "GET_UNIQUE_TAGS_IN_BETWEEN_YEARS":
                return "q";
            case "GET_RISING_STARS":
                return "a";
            case "ADD_TAGS":
                ArrayList<String>tagsPedidas = new ArrayList<>();
                String[] tags = input[1].split(";"); // divide pelo ;
                String artistaPedido = tags[0];
                for (int i = 1 ; i < tags.length ; i++) { // comeca no 1 porque o zero é o artista
                    tagsPedidas.add(tags[i].trim().toUpperCase()); // colocar a TAG em maiscula sem espaco
                }
                return FunctionsArtist.tagsAdd(listadeArtistas,artistaPedido,tagsPedidas); // tags[0] sera o artista
            case "REMOVE_TAGS":
                ArrayList<String>tagsPedidas2 = new ArrayList<>();
                String[] tags2 = input[1].split(";"); // divide pelo ;
                for (int i = 1 ; i < tags2.length ; i++) { // comeca no 1 porque o zero é o artista
                    tagsPedidas2.add(tags2[i].trim().toUpperCase()); // colocar a TAG em maiscula sem espaco
                }
                return FunctionsArtist.removeTaggs(listadeArtistas,tags2[0],tagsPedidas2);
            case "GET_MOST_DURATION_YEAR":
                String[] dadosDuracao = input[1].split(" ");
                int anoPedido= Integer.parseInt(dadosDuracao[0]);
                int duracaoPedida = Integer.parseInt(dadosDuracao[1]);
                return FunctionsSongs.getMostDurationThatYear(listadeSons,listadetalhes,anoPedido,duracaoPedida);
            case "CLEANUP":
                return "l";
            default:
                return "Illegal command. Try again";
        }
    }
    public static void main(String[] args) throws IOException {
        loadFiles();
        System.out.println("Welcome to DEISI Rockstar!"); Scanner in = new Scanner(System.in);
        String line = in.nextLine(); // linha vai ser a primeira palavra
        while (line != null && !line.equals("KTHXBYE")) {
            long start = System.currentTimeMillis();
            String result = execute(line);
            long end = System.currentTimeMillis();
            System.out.println(result);
            System.out.println("(took " + (end - start) + " ms)");
            line = in.nextLine();
        }
    }
}