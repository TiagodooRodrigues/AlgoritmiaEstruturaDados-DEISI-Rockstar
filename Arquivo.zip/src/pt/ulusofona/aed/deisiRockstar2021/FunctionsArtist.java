package pt.ulusofona.aed.deisiRockstar2021;

import jdk.swing.interop.SwingInterOpUtils;

import java.net.PortUnreachableException;
import java.net.http.HttpHeaders;
import java.util.*;

public class FunctionsArtist {
    public static int binarySearch(ArrayList<Artista> a, String key) { // pesquisa binaria para ids entre musicas e artistas
        int lo = 0;
        int hi = a.size() - 1;
        while (hi >= lo) {
            int mid = (lo + hi) / 2;
            if (a.get(mid).nome.compareTo(key) < 0) {
                lo = mid + 1;
            } else if (a.get(mid).nome.compareTo(key) > 0) {
                hi = mid - 1;
            }
            else {
                return mid;
            }
        }
        return -1;
    }
    public static String get_ArtistForTag(ArrayList<Artista> artistas , String tag) {
        StringBuilder resultado = new StringBuilder();
        ArrayList<Artista> artistasTag = new ArrayList<Artista>();

        if (artistas == null || tag == null) {
            return "No results";
        }
        for (Artista artista : artistas) {
            if (artista.tags.contains(tag)) { // se o artista tiver essa tag
                artistasTag.add(artista);
            }
        }
        if (artistasTag.isEmpty()) {
            return "No results";
        }
        for (int i  = 0 ; i < artistasTag.size() ; i++) {
            resultado.append(artistasTag.get(i).nome);
            if ( i != artistasTag.size() - 1) {
                resultado.append(";");
            }
        }
        return resultado.toString();
    }
    public static String removeTaggs(ArrayList<Artista> artistas , String artistaPedido, ArrayList<String> tags) {
        StringBuilder resultado = new StringBuilder();
        Artista artista = new Artista(null, null, null);
        if (artistas == null || artistaPedido == null) { // caso for null
            return "Inexistent artist";
        }
        boolean temArtista = false;
        for (Artista nomeDoArtista : artistas) {
            if (nomeDoArtista.nome.equals(artistaPedido)) {
                temArtista = true;  // guardar se encontramos o nome
                artista = nomeDoArtista; // guardar o artista encontrado
            }
        }
        if (!temArtista) { // o artista nao existe
            return "Inexistent artist";
        } else {
            for (String tag : tags) {
                if (artista.tags.contains(tag)) {
                    artista.tags.remove(tag);
                }
            }
            resultado.append(artista.nome);
            resultado.append(" | ");
            if (artista.tags.size() == 0) {
                resultado.append("No tags");
            } else {
                for (int i = 0; i < artista.tags.size(); i++) {
                    resultado.append(artista.tags.get(i));
                    if (i != artista.tags.size() - 1) {
                        resultado.append(",");
                    }
                }
            }
            return resultado.toString();
        }
    }
    public static String tagsAdd(ArrayList<Artista> artistas, String artistaPedido , ArrayList<String> tags) {
        StringBuilder resultado = new StringBuilder();
        Artista artista = new Artista(null,null,null);
        if (artistas == null || artistaPedido == null) { // caso for null
            return "Inexistent artist";
        }
        boolean temArtista = false;
        for (Artista nomeDoArtista : artistas) {
            if (nomeDoArtista.nome.equals(artistaPedido)) {
                temArtista = true;  // guardar se encontramos o nome
                artista = nomeDoArtista; // guardar o artista encontrado
            }
        }
        if (!temArtista) { // o artista nao existe
            return "Inexistent artist";
        } else {
            for (String tag : tags) {
                if (!(artista.tags.contains(tag))) { // se nao tiver essa tag
                    artista.tags.add(tag);
                }
            }
            resultado.append(artista.nome);
            resultado.append(" | ");
            for (int i = 0; i < artista.tags.size(); i++) {
                resultado.append(artista.tags.get(i));
                if ( i != artista.tags.size() - 1) {
                    resultado.append(",");
                }
            }
        }
        return resultado.toString();
    }

    public static String getArtistsOneSong(int anoInicio ,int anoFim) {
        StringBuilder resultado = new StringBuilder();
        if (anoInicio >= anoFim) {  //erro
            return "Invalid period";
        }
        ArrayList<Song> musicasAnos = new ArrayList<>();

        for (Song som : Main.listadeSons) { // reduzir a lista para musicas desses anos
            if (som.anoLancamento >= anoInicio && som.anoLancamento <= anoFim) {
                musicasAnos.add(som);
            }
        }

        ArrayList<Song> musicasOrdenadas = new ArrayList<Song>();
        musicasOrdenadas.addAll(musicasAnos);
        musicasOrdenadas.sort(Comparator.comparing((Song som1) -> som1.iD)); // musicas ordendas nesse periodo de anos


        ArrayList<Artista> artistasOrdenado = new ArrayList<>();
        artistasOrdenado.addAll(Main.listadeArtistas);
        artistasOrdenado.sort(Comparator.comparing((Artista artista) -> artista.nome)); // artistas ordenados

       artistasOrdenado.removeIf(artista -> FunctionsSongs.binarySearch(musicasOrdenadas, artista.iD) == -1); // remover artistas sem musicas desses anos

        HashSet<String> duplicados = new HashSet<>();
        ArrayList<Artista> artistasCom1Som = new ArrayList<>();

        for (Artista artista : artistasOrdenado) { // entre os artistas com musicas desses anos
           if (duplicados.add(artista.nome)) { // se nao for duplicado
                artistasCom1Som.add(artista);
            } else {
               duplicados.add(artista.nome); // se for duplicado
               int index = binarySearch(artistasCom1Som,artista.nome);// procurar pelo duplicado
               if (index != -1) {
                   artistasCom1Som.remove(index); // remover o artista que continha duplicacao
               }
            }
        }
       artistasCom1Som.sort(Comparator.comparing((Artista artista) -> artista.nome)); // ordernar os artistas com 1 som pelo nome

        for (Artista artista : artistasCom1Som ){
            int index = FunctionsSongs.binarySearch(musicasOrdenadas,artista.iD);
            // encontrou um artista com uma musica desses anos
                resultado.append(artista.nome);
                resultado.append(" | ");
                resultado.append(musicasOrdenadas.get(index).titulo);
                resultado.append(" | ");
                resultado.append(musicasOrdenadas.get(index).anoLancamento);
                resultado.append("\n");
        }
        if (!resultado.toString().equals("")) {
            int last = resultado.lastIndexOf("\n"); // encontra a posicao do \n
            if (last == resultado.length() - 1) { // caso a ultima linha seja \n
                resultado.delete(last, resultado.length());  // remover \n
            }
        }
        return resultado.toString();
    }
}
