package pt.ulusofona.aed.deisiRockstar2021;
import org.junit.Test;
import static org.junit.Assert.*;

public class Testes {
    @Test
    public void test1Song() {
        Song resultadoReal = new Song("7dD5DEzjhofoItSG7QwVoY","Lusofona no Maximo",2021);
        System.out.println(resultadoReal.toString());
        String resultadoEsperado = "7dD5DEzjhofoItSG7QwVoY | Lusofona no Maximo | 2021";
        assertEquals("Deveria dar: ",resultadoEsperado,resultadoReal.toString());
    }
    @Test
    public void test2Song() {
        Song resultadoReal = new Song("Acabei o Projeto");
        String resultadoEsperado = "null | Acabei o Projeto | 0";
        assertEquals("Deveria dar:",resultadoEsperado,resultadoReal.toString());
    }
}

