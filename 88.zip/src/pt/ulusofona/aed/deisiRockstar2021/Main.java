package pt.ulusofona.aed.deisiRockstar2021;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
public class Main {
    public static ArrayList<Song> listadeSons;
    public static  ArrayList<Artista> listadeArtistas;
    public static ArrayList<Song> listadetalhes;
    public static ParseInfo infoSongs = new ParseInfo(0,0);
    public static ParseInfo infoSongs1 = new ParseInfo(0,0);
    public static ParseInfo infoSongs2 = new ParseInfo(0,0);

    public static void loadFiles() throws IOException {
        String ficheiro_song_artits = "song_artists.txt";
        try {
            listadeArtistas= new ArrayList<Artista>();
            infoSongs = new ParseInfo(0,0);
            File ficheiro = new File(ficheiro_song_artits);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine(); // Ler a linha do ficheiro
                String dados[] = linha.split("@");
                if (dados.length == 2) {
                    String ID = dados[0];
                    String nome = dados[1];
                    // Criar objeto artistas
                    Artista artista = new Artista(ID, nome);
                    listadeArtistas.add(artista);
                    infoSongs.numLinhasOk++;
                } else {
                    infoSongs.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_song_artits + " não foi encontrado. ";
            System.out.println(mensagem);
        }
        ///////// FIM de Leitura de Song_artits.txt/////////////////////////
        String ficheiro_song_details = "song_details.txt";
        try {
            listadetalhes = new ArrayList<Song>();
            infoSongs1 = new ParseInfo(0,0);
            File ficheiro = new File(ficheiro_song_details);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine();// Ler a linha do ficheiro
                String dados[] = linha.split("@");
                if (dados.length == 7) {
                    String ID = dados[0]; // ID tema musical
                    dados[1] = dados[1].trim();
                    int duracao = Integer.parseInt(dados[1]); // duracao
                    dados[2] = dados[2].trim();
                    int letra = Integer.parseInt(dados[2]);  // letra
                    dados[3] = dados[3].trim();
                    int popularidade = Integer.parseInt(dados[3]); // popularidade
                    dados[4] = dados[4].trim();
                    float dancabilidade = Float.parseFloat(dados[4]); // dancabilidade
                    dados[5] = dados[5].trim();
                    float vivacidade = Float.parseFloat(dados[5]);  // dancabilidade
                    dados[6] = dados[6].trim();
                    float volumeMedio = Float.parseFloat(dados[6]); // volume medio
                    // Criar objeto artistas
                    Song detalhes = new Song(ID, duracao, letra, popularidade, dancabilidade, vivacidade, volumeMedio);
                    listadetalhes.add(detalhes);
                    infoSongs1.numLinhasOk++;
                } else {
                    infoSongs1.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_song_details + " não foi encontrado. ";
            System.out.println(mensagem);
        }
        //////// fim do ficheiro song_details.txt///////////////////////
        String ficheiro_songs = "songs.txt";
        try {
            listadeSons = new ArrayList<Song>();
            infoSongs2 = new ParseInfo(0,0);
            File ficheiro = new File(ficheiro_songs);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                String linha = leitorFicheiro.nextLine();
                String dados[] = linha.split("@");
                if (dados.length == 3) {
                    dados[0] = dados[0].trim();
                    String ID = dados[0];
                    dados[1] = dados[1].trim();
                    String nome = dados[1];
                    dados[2] = dados[2].trim();
                    int ano = Integer.parseInt(dados[2]);
                    // Criar objetos artistas
                    Song sons = new Song(ID, nome, ano);
                    listadeSons.add(sons);
                    infoSongs2.numLinhasOk++;
                } else {
                    infoSongs2.numLinhasIgnored++;
                }
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiro_songs + " não foi encontrado. ";
            System.out.println(mensagem);
        }
    }
    public static ParseInfo getParseInfo(String fileName) {
        if (fileName.equals("song_artists.txt")) {
            return infoSongs;
        }
        if (fileName.equals("songs.txt")) {
            return infoSongs2;
        }
        if (fileName.equals("song_details.txt")) {
            return infoSongs1;
        }
        return null;
    }
    public static ArrayList<Song> getSongs() {
        return listadeSons;
    }
    public static void main(String[] args) throws IOException {
        loadFiles();
        loadFiles();
        loadFiles();
        System.out.println(getParseInfo("songs.txt"));
    }
}