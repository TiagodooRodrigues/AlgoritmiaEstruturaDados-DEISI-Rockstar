package pt.ulusofona.aed.deisiRockstar2021;

public class Song {
    String iD;
    String titulo;
    Artista[] artistas;
    int anoLancamento;
    int duracaoDoTema;
    int letraExplicita;
    int popularidade;
    float grauDancabilidade;
    float grauVivacidade;
    float volumeMedio;

    public Song(String titulo) {
        this.titulo = titulo;
    }

    public Song(String ID, String titulo, int anoLancamento) { // Songs.txt
        this.iD = ID;
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
    }
    public Song (String ID, int duracaoDoTema, int letraExplicita, int popularidade, float grauDancabilidade, float grauVivacidade,float volumeMedio) {
        this.iD = ID;
        this.duracaoDoTema = duracaoDoTema;
        this.letraExplicita = letraExplicita;
        this.popularidade = popularidade;
        this.grauDancabilidade = grauDancabilidade;
        this.grauVivacidade = grauVivacidade;
        this.volumeMedio = volumeMedio;
    }
    public Song(String ID, String titulo, Artista[] artistas, int anoLancamento, int duracaoDoTema, int letraExplicita, int popularidade, float grauDancabilidade, float grauVivacidade, float volumeMedio) {
        this.iD = ID;
        this.titulo = titulo;
        this.artistas = artistas;
        this.anoLancamento = anoLancamento;
        this.duracaoDoTema = duracaoDoTema;
        this.letraExplicita = letraExplicita;
        this.popularidade = popularidade;
        this.grauDancabilidade = grauDancabilidade;
        this.grauVivacidade = grauVivacidade;
        this.volumeMedio = volumeMedio;
    }
    public String toString() {
        return "" + iD + " | " + titulo + " | " + anoLancamento;
    }
}
