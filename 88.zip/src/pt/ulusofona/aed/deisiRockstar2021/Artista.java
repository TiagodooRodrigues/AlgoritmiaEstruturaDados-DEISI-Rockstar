package pt.ulusofona.aed.deisiRockstar2021;

public class Artista {
        String iD;
        String nome;

        public Artista(String ID, String nome) {
            this.iD = ID;
             nome = nome;
        }
    }
