package pt.ulusofona.aed.deisiRockstar2021;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

public class FunctionsLoadfilesArtist {
    public static HashSet<String> guardaIDs;
    public static HashSet<String> nomesRepetidos;
    public static void loadfilesArtistas(String ficheiroArtistas) {
        try {
            Main.listadeArtistas = new ArrayList<Artista>();
            Main.infoSongs = new ParseInfo(0, 0);
            ArrayList<Song> OrdenadoPB = new ArrayList<>(); //copiar songs de forma ordenanda
            OrdenadoPB.addAll(Main.listadeSons2);
            OrdenadoPB.sort(Comparator.comparing((Song som1) -> som1.iD)); //ordernado por IDs os detalhes
            File ficheiro = new File(ficheiroArtistas);
            FileInputStream fis1 = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis1);
            nomesRepetidos = new HashSet<>();
            guardaIDs = new HashSet<>();
            while (leitorFicheiro.hasNextLine()) { // enquanto tiver linhas...
                leituraFicheiroArtistas(leitorFicheiro, OrdenadoPB);
            }
            leitorFicheiro.close();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + ficheiroArtistas + " não foi encontrado. ";
            System.out.println(mensagem);
        }
    }

    public static void leituraFicheiroArtistas(Scanner leitorFicheiro, ArrayList<Song> OrdenadoPB) {
        String linha = leitorFicheiro.nextLine(); // Ler a linha do ficheiro
        String dados[] = linha.split("@");
        int temArtistaVazio = 0;
        if (dados.length == 2) {
            String ID = dados[0].trim();
            if (ID.equals("") || !Main.verificarIDvalido(OrdenadoPB, ID)) { // se nao tiver id
                Main.infoSongs.numLinhasIgnored++;
            } else {
                adicionarArtista(dados,ID,temArtistaVazio);
            }
        } else {
            Main.infoSongs.numLinhasIgnored++;
        }
    }
    public static void adicionarArtista(String[] dados , String ID , int temArtistaVazio) {
        if (guardaIDs.add(ID)) {
            if (dados[1].contains(",")) { // caso seja mais que um artista
                String[] nomes = dados[1].split(","); //dividir por ,
                for (String nome : nomes) {
                    nome = nome.replace("[", "").replace("]", "").replace("'", "").replace("\"", "").trim(); //retirar peliculas e '
                    if (nome.equals("")) {
                        temArtistaVazio = 1;
                    }
                }
                if (temArtistaVazio == 1) {
                    Main.infoSongs.numLinhasIgnored++; // encontrou artista vazio por isso ignora
                } else {
                    for (String nome : nomes) {
                        // nome = nome.replace("[", "").replace("]", "").replace("'", "").replace("\"", "").trim(); //retirar peliculas e '
                        nome = replaceArtist(nome);
                        if (nomesRepetidos.add(nome)) {
                            Artista artista = new Artista(ID, nome);
                            Main.listadeArtistas.add(artista);
                            nomesRepetidos.add(nome);
                        }
                    }
                    nomesRepetidos.clear();
                    Main.infoSongs.numLinhasOk++; // leu a linha toda
                }
            } else { // tem apenas uma artista
                //String nome = dados[1].replace("[", "").replace("]", "").replace("'", "").replace("\"", "").trim(); // retirar peliculas e []
                String nome = dados[1];
                nome = replaceArtist(nome);
                if (nome.equals("")) {
                    Main.infoSongs.numLinhasIgnored++; // encontrou artista vazio por isso ignora
                } else {
                    // Criar objeto artistas
                    Artista artista = new Artista(ID, nome);
                    Main.listadeArtistas.add(artista);
                    Main.infoSongs.numLinhasOk++;
                }
            }
            guardaIDs.add(ID);
        } else {
            Main.infoSongs.numLinhasOk++;
        }
    }
    public static String replaceArtist(String nome) {
        nome = nome.trim();
        nome = nome.replace("\"['","");
        nome = nome.replace("']\"","");
        nome = nome.replace("'[\"","");
        nome = nome.replace("\"]'","");
        nome = nome.replace("['","");
        nome = nome.replace("']","");
        nome = nome.replace("'[","[");
        nome = nome.replace("]'","]");
        nome = nome.replace("\"[","");
        nome = nome.replace("]\"","");
        nome = nome.replace("\"\"'","");
        nome = nome.replace("\"'","");
        nome = nome.replace("'\"\"","");
        nome = nome.replace("'\"","");
        nome = nome.replace("\"\"\"","\"");
        nome = nome.replace("\"\"","");
        if (nome.startsWith("\'")) {
            nome = nome.substring(1);
        }
        if (nome.endsWith("\'")) {
            nome = nome.substring(0,nome.length() -1);
        }
        return nome;
    }
}
