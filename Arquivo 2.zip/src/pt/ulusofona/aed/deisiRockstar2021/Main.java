package pt.ulusofona.aed.deisiRockstar2021;

import java.util.*;
import java.io.*;
public class Main {
    public static HashSet<Song> listadeSons;
    public static  ArrayList<Artista> listadeArtistas;
    public static HashSet<Song> listadetalhes;
    public static  ArrayList<Song> listadeSons2;
    public static  ArrayList<Song> listaDetalhes2;
    public static ParseInfo infoSongs = new ParseInfo(0,0);
    public static ParseInfo infoSongs1 = new ParseInfo(0,0);
    public static ParseInfo infoSongs2 = new ParseInfo(0,0);

    public static void loadFiles() throws IOException {
        String ficheiro_songs = "songs.txt";
        FunctionsLoadfilesSongs.leituraSons(ficheiro_songs);
        ///////// FIM de Leitura de Songs/////////////////////////
        String ficheiro_song_details = "song_details.txt";
        FunctionsLoadfilesDetails.leituraDetalhes(ficheiro_song_details);
        //////// fim do ficheiro detalhes.txt///////////////////////
        String ficheiro_song_artits = "song_artists.txt";
        FunctionsLoadfilesArtist.loadfilesArtistas(ficheiro_song_artits);
    }
    public static ParseInfo getParseInfo(String fileName) {
        if (fileName.equals("song_artists.txt")) {
            return infoSongs;
        }
        if (fileName.equals("songs.txt")) {
            return infoSongs2;
        }
        if (fileName.equals("song_details.txt")) {
            return infoSongs1;
        }
        return null;
    }
    public static ArrayList<Song> getSongs() {
        return listadeSons2;
    }
    public static String getCreativeQuery() {
        return "GET_MOST_DURATION_YEAR";
    }
    public  static int getTypeOfSecondParameter() {
        return 1;
    }
    public static String getVideoUrl(){
        return "https://youtu.be/ghX17j6fC_s";
    }
    public static boolean verificarIDvalido(ArrayList<Song> copia ,String Id) {
        return FunctionsSongs.binarySearch(copia, Id) != -1;
    }
    public static String execute(String command) {
        String[] input = command.split(" ",2); // divide a string em espacos mas com limite dois
        return SwitchExecute.switchExecuteFuction1(input);
    }
    public static void main(String[] args) throws IOException {
        loadFiles();
        System.out.println("Welcome to DEISI Rockstar!"); Scanner in = new Scanner(System.in);
        String line = in.nextLine(); // linha vai ser a primeira palavra
        while (line != null && !line.equals("KTHXBYE")) {
            long start = System.currentTimeMillis();
            String result = execute(line);
            long end = System.currentTimeMillis();
            System.out.println(result);
            System.out.println("(took " + (end - start) + " ms)");
            line = in.nextLine();
        }
    }
}