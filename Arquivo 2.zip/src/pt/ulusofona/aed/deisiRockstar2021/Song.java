package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;

public class Song {
    String iD;
    String titulo;
    ArrayList<Artista> artistas = Main.listadeArtistas;
    int anoLancamento;
    int duracaoDoTema;
    int letraExplicita;
    double popularidade;
    double grauDancabilidade;
    double grauVivacidade;
    double volumeMedio;

    public Song(String titulo) {
        this.titulo = titulo;
    }

    public Song(String ID, String titulo, int anoLancamento) { // Songs.txt
        this.iD = ID;
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
    }
    public Song (String ID, int duracaoDoTema, int letraExplicita, double popularidade, double grauDancabilidade, double grauVivacidade,double volumeMedio) {
        this.iD = ID;
        this.duracaoDoTema = duracaoDoTema;
        this.letraExplicita = letraExplicita;
        this.popularidade = popularidade;
        this.grauDancabilidade = grauDancabilidade;
        this.grauVivacidade = grauVivacidade;
        this.volumeMedio = volumeMedio;
    }
    public Song(String ID, String titulo, ArrayList<Artista> artistas, int anoLancamento, int duracaoDoTema, int letraExplicita, double popularidade, double grauDancabilidade, double grauVivacidade, double volumeMedio) {
        this.iD = ID;
        this.titulo = titulo;
        this.artistas = artistas;
        this.anoLancamento = anoLancamento;
        this.duracaoDoTema = duracaoDoTema;
        this.letraExplicita = letraExplicita;
        this.popularidade = popularidade;
        this.grauDancabilidade = grauDancabilidade;
        this.grauVivacidade = grauVivacidade;
        this.volumeMedio = volumeMedio;
    }
    public ArrayList<Integer> numeroDeTemas() { // devolve lista de numero de temas na lista de artistas correspondente a musica
        ArrayList<Integer> numerotemas = new ArrayList<Integer>();
        int contador = 0;
        for (Artista artista : artistasdesseID()) { // entre os artistas do id da musica
            for (Artista artista2 : Main.listadeArtistas) {
                if (artista.nome.equals(artista2.nome)) {
                    contador++;
                }
            }
            numerotemas.add(contador);
            contador = 0;
        }
        return numerotemas;
    }
    public ArrayList<Artista> artistasdesseID() { // devolve lista de artista da musica correspondente
        ArrayList<Artista> lista = new ArrayList<Artista>();
        if ( Main.listadeArtistas != null ) {
            for (Artista artista : Main.listadeArtistas) {
                if (artista.iD.equals(iD)) {
                    lista.add(artista);
                }
            }
        }
        return lista;
    }
    public String toString() {
        double popularidadeCalculada = 0.0;
        int minutos = 0;
        int segundos = 0;
        StringBuilder todosOsArtistas = new StringBuilder();
        if ( artistasdesseID() != null ) {
            for (int i = 0 ; i < artistasdesseID().size() ; i ++) { // escrever os artistas
                todosOsArtistas.append(artistasdesseID().get(i).nome);
                if (i != artistasdesseID().size() - 1){ // caso seja mais que artista que tenha essa musica
                    todosOsArtistas.append(" / ");
                }
            }
            todosOsArtistas.append(" | ");
            todosOsArtistas.append("(");
            for (int i = 0 ; i < numeroDeTemas().size() ; i ++) { // adicionar o numero de temas
                todosOsArtistas.append(numeroDeTemas().get(i));
                if (i != artistasdesseID().size() - 1) {
                    todosOsArtistas.append(" / ");
                }
            }
            todosOsArtistas.append(")");
        }
        for (Song musica : Main.listaDetalhes2) {
            if (musica.iD.equals(iD)) {
                popularidadeCalculada = musica.popularidade;
                minutos = (musica.duracaoDoTema / 1000) / 60;
                segundos = (musica.duracaoDoTema / 1000) % 60;
            }
        }
        return iD + " | " + titulo + " | " + anoLancamento + " | " + minutos + ":"+ segundos + " | "+ popularidadeCalculada + " | " + todosOsArtistas;
    }
}
