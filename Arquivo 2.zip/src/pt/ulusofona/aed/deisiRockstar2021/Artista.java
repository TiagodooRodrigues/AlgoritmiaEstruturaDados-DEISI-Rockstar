package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;

public class Artista {
        String iD;
        String nome;
        ArrayList<String> tags = new ArrayList<>();

        public Artista(String ID, String nome) {
            this.iD = ID;
            this.nome = nome;
        }
    public Artista(String iD, String nome, ArrayList<String> tags) {
        this.iD = iD;
        this.nome = nome;
        this.tags = tags;
    }
}
