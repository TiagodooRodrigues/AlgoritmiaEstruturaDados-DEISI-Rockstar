package pt.ulusofona.aed.deisiRockstar2021;

public class Etiquetas {
    String nome;
    int consideraveis;
    int totais;

    public Etiquetas(String nome, int consideraveis, int totais) {
        this.nome = nome;
        this.consideraveis = consideraveis;
        this.totais = totais;
    }
}
